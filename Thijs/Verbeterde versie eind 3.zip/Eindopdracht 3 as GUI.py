# -*- coding: utf-8 -*-
"""
Created on Thu Apr  6 12:28:54 2017
Vanuit een multiple fasta bestand, een hydropatie grafiek maken.
>>>Voer dit script niet uit buiten een mapje<<<

Gemaakt door: Thijs Weenink
Version: 2.0


#Note 1:
Bestand omzetten gehaald van https://cartwrightlab.wikispaces.com/File+Formatting#Remove%20Line%20Breaks%20from%20Sequences
Variabelen omgezet naar meer logische namen

De rest van de code is zelf geschreven. Doordat ik mensen heb geholpen, kunnen er overeenkomsten zijn.
"""
import matplotlib.pyplot as plt
import tkinter as gui
from tkinter import *
from tkinter import messagebox
from PIL import Image, ImageTk
import re
import numpy as np
from Bio.SeqUtils import seq3
                                                            
class GUI:
    
    def __init__(self):
        self.mainwindow = gui.Tk()
        self.mainwindow.wm_title('Eindopdracht course 3')
        self.mainwindow.minsize(400,200)

        self.maintop = gui.Frame(self.mainwindow)
        self.maindown = gui.Frame(self.mainwindow)

        self.filebutton = gui.Button(self.maintop, text='Open file', command=self.get_proteins)
        self.graphbutton = gui.Button(self.maindown, text='Make graph', command=self.get_hydropathy)

        self.fileinput = gui.Entry(self.maintop)
        self.accinput = gui.Entry(self.maindown)
        
        self.codes = gui.StringVar()
        self.error1 = gui.StringVar()
        self.error2 = gui.StringVar()
        
        self.acctitel = gui.Label(self.maintop, text='Accessiecodes:')
        self.accessiecodes = gui.Label(self.maintop, textvariable=self.codes, borderwidth=2, relief='groove')
        self.errors1 = gui.Label(self.maintop, textvariable=self.error1)
        self.errors2 = gui.Label(self.maindown, textvariable=self.error2)
        self.graphkeuze = gui.Label(self.maindown, text='Accessiecode voor grafiek:')
        
        self.maintop.pack()
        self.maindown.pack()
        
        self.errors1.pack()
        self.fileinput.pack()
        self.filebutton.pack()
        self.acctitel.pack()
        self.accessiecodes.pack()
        self.errors2.pack()
        self.graphkeuze.pack()
        
        self.accinput.pack()
        self.graphbutton.pack()
        
        
        gui.mainloop()
    
    
    def get_proteins(self):
        bestandnaam = self.fileinput.get()
        Go_ahead = True
        
        try:
            Original = open(bestandnaam+'.fa')
            Edited = open('fixedprotgui.txt','w')              # Openen 2e bestand voor plakken sequenties zonder enters
        except FileNotFoundError:
            print('File not found, try again')
        
        try:        
            line = Original.readline()
             
            while line: 
                Edited.write(line)                              # Schrijf de regel in het bestand
                sequenceList = [] 
                line = Original.readline() 
                while line and not line.startswith('>'):        # While loop voor 1 of meer regels, die niet '>'bevatten
                    sequenceList.append(line.strip('\n')) 
                    line = Original.readline()                  
                Edited.write('%s\n' % ''.join(sequenceList))    # Verwijderen van de \n uit de sequentie
        
            self.error1.set(' ')
            self.error2.set(' ')
            Original.close()
            Edited.close()
        
        except UnboundLocalError:
            self.error1.set('File not found, try again')
            Go_ahead = False
            
        if Go_ahead:    
            file = open('fixedprotgui.txt')
        
            self.acces = []
            sequence = []
            
            for line in file.readlines():
                accessie = re.search('\|.+\|',line)             # Zoeken van de accessiecode
                if accessie != None:                            # Alleen headers
                    start = accessie.start()
                    end = accessie.end()
                    self.acces.append(line[start+1:end-1])           # Zonder de |
                else:
                    sequence.append(line.replace('\n',''))
            
            self.codes.set(self.acces)
                    
            self.Combined = dict(zip(self.acces,sequence))
    
    def get_def(self):  
                                                   # BioPython omdat ik dat had in plaats van het aanpassen van de dictionary
        try:                                       # seq3() = BioPython, maakt van de 1 lettercode een 3 lettercode                           
            patroon_true = []                                    
            patroon_false = []
            codes_true = []
            codes_false =[]
            
            for code in self.acces:
                seq = self.Combined.get(code)
                defensin = re.search('C.C.{3,5}C.{7}G.C.{9}CC',seq)
                if defensin != None:
                    #print('Deze sequentie bevat het consensus patroon\n',seq[defensin.start():defensin.end()])
                    patroon_true.append(seq3(seq))
                    codes_true.append(code)
                    self.Defensins = dict(zip(codes_true,patroon_true))
                else:
                    #print('Deze sequentie bevat niet het consensus patroon')
                    patroon_false.append(seq3(seq))
                    codes_false.append(code)
                    Dict_acc_pat_false = dict(zip(codes_false,patroon_false)) #--------------------------------------------------------------------------------------------------------------------------------------------Maakt de dictinary leesbaar--------------------------------------------------------
        except AttributeError:
            print('please select file first')
            self.error2.set(' ')
            self.error2.set('Please open a file first')    
        #print(Defensins)
        #print(Dict_acc_pat_false)
    
    def get_hydropathy(self):        
        self.get_def()
        
        try:    
            choice = self.accinput.get()
            self.error2.set(' ')
                
            hydropatie = {"Ile":-0.528,"Leu":-0.342,"Phe":-0.370,"Val":-0.308,"Met":-0.324,"Pro":-0.322,"Trp": -0.270,"His": 2.029,"Thr": 0.853,"Glu": 3.173,"Gln": 2.176,"Cys": 0.081,"Tyr": 1.677,"Ala":-0.495,"Ser": 0.936,"Asn": 2.354,"Asp": 9.573,"Arg": 4.383,"Gly": 0.386,"Lys": 2.101}
            
            try:    
                numbers = [ hydropatie.get(acid) for acid in [ self.Defensins.get(choice)[start:start+3] for start in range(0, len(self.Defensins.get(choice)), 3) ]]
                
                # Bovenstaande is hetzelfde als onderstaande:
                # numbers = []
                # sequentie = Defensins.get(choice)
                # for acid in [ sequentie[start:start+3] for start in range(0, len(sequentie), 3) ]:
                #   numbers.append(hydropatie.get(acid))
                    
                xs = range(len(numbers))
                ys = numbers
                
                plt.figure(figsize=(13,7))
                plt.plot(xs, ys, color='gray')
                plt.ylabel('Hydropatie waardes')
                plt.xlabel('Aminozuur nummer')
                plt.title(choice)
                
                plt.fill_between(xs, 0, ys, where=np.asarray(ys) > 0, color='green', interpolate=True)    
                plt.fill_between(xs, 0, ys, where=np.asarray(ys) < 0, color='red', interpolate=True)
                plt.fill_between(xs, 0, ys, where=np.asarray(ys) == 0, color='blue', interpolate=True)
                # Zorgt voor de inkleuring van de lijn boven en onder y=0
                
                plt.savefig(choice+'.png')                                      # Nodig voor display
                
                load = Image.open(choice+'.png')
                render = ImageTk.PhotoImage(load)
                
                window2 = gui.Toplevel()
                window2.wm_title('Graph of '+choice)
                img = Label(window2, image=render)
                img.image = render
                img.pack()
                
                useless = gui.Button(window2, text='Save graph as png')         # Het figuur wordt al opgeslagen als png om de laten zien in window2
                useless.pack()                                                  # Zie het als 'cache' geheugen
                useless.place(rely=1.0, relx=1.0, x=0, y=0, anchor=SE)
            except AttributeError:
                print('please select file first')
                self.error2.set(' ')
                self.error2.set('Please open a file first')                     # Print dubbel in in console door ook de error in get_def
        except TypeError:                                                       # 1 afvangen is niet genoeg.
            print('Code not found')
            self.error2.set(' ')
            self.error2.set('Code not found, try a different one')
        
GUI()
